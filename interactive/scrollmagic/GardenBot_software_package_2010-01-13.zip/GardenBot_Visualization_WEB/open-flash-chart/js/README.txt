***************
** JS Folder **
***************

Here are some Javascript libraries used on the code or samples.

- swfobject.js

  SWFObject v1.5: Flash Player detection and embed - http://blog.deconcept.com/swfobject/
  *
  * SWFObject is (c) 2007 Geoff Stearns and is released under the MIT License:
  * http://www.opensource.org/licenses/mit-license.php
